# Example for While Loop
total = 0	#while loop example 1,3,6
number = int(input(" Please Enter any integer below 100:  "))#99
while(number <= 100):#5
	total = total + number #5
	number = number + 1
print(" Value of Total From the While Loop is: ", total)

