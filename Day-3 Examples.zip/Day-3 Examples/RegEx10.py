import re
matchobj=re.search("^ericsson","ericsson india pvt limited")
matchobj1=re.search("ericsson$","ericsson india pvt limited")
print(matchobj)
print(matchobj1)