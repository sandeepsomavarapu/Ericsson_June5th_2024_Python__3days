from datetime import date
from datetime import time
from datetime import datetime
#Date

# todaysDate=date.today()
# print(todaysDate)
# print(todaysDate.year)
# print(todaysDate.month)
# print(todaysDate.day)
# dob=date(1992,11,10)
# print(dob)

#Time
ctime=time.time()
print(ctime)
print(ctime.hour," ",ctime.minute,' ',ctime.second)

datetime1=datetime.now()
print(datetime1)
print(datetime1.year)