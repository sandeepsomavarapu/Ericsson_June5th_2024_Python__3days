try:
    file=open("socGen.txt","r")
    print(file.read())
    num=int(input("Enter any number for division : "))#0
    result = 12 /num #PVM
    print("Result is", result)#error code/risky code 
except ZeroDivisionError:
    print("dont enter zero as denominator")
except ValueError:
    print("Enter only number")
except Exception as ex:
    print("some other exception : ",ex.__class__)
finally:
    print("will execute always for clean up code")
print("Remaining lines of code")





#system defined error messages
#abnormal termination


#normal ternimation
#user friendly error message 












