import re

matcher=re.finditer("\\W","a7b@k 9Z") #[abc]
for match in matcher:
    print(match.start(),"...",match.group())