age=29
def sayHello(msg):
	print("welcome to python"+msg)
